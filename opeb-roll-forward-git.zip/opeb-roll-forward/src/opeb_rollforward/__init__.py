"""
OPEB Roll-Forward Model

Production-ready GASB 75 roll-forward model for year-over-year
OPEB liability projections and experience analysis.

Author: Actuarial Pipeline Project
Version: 2.0.0
"""

__version__ = "2.0.0"
__author__ = "Actuarial Pipeline Project"

from .engine import (
    RollForwardEngine,
    PriorValuation,
    RollForwardResults,
    create_engine,
    load_prior
)

__all__ = [
    "RollForwardEngine",
    "PriorValuation", 
    "RollForwardResults",
    "create_engine",
    "load_prior",
]
