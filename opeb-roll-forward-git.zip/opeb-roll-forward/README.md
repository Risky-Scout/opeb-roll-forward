# OPEB Roll-Forward Model

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![GASB 75 Compliant](https://img.shields.io/badge/GASB%2075-Compliant-green.svg)](https://www.gasb.org/)

Production-ready GASB 75 roll-forward model for year-over-year OPEB liability projections and experience analysis.

## Features

- **TOL Roll-Forward** per GASB 75 ¶96
- **Interest Cost Calculation** per GASB 75 ¶44
- **Duration-Based Rate Sensitivity**
- **Experience Gain/Loss Decomposition**
- **Reconciliation Table Generation**

## Installation

```bash
git clone https://github.com/YOUR_USERNAME/opeb-roll-forward.git
cd opeb-roll-forward
pip install -e .
```

## Quick Start

```python
from opeb_rollforward import RollForwardEngine, PriorValuation
from datetime import date

prior = PriorValuation(
    valuation_date=date(2024, 9, 30),
    total_opeb_liability=6911729,
    service_cost=650000,
    discount_rate_boy=0.0409,
    discount_rate_eoy=0.0381,
    tol_actives=2100000,
    tol_retirees=4800000,
)

engine = RollForwardEngine(
    prior_valuation=prior,
    current_date=date(2025, 9, 30),
    benefit_payments=450000,
    new_discount_rate=0.0381,
    actual_eoy_tol=10201072
)

results = engine.run()
print(f"Experience (Gain)/Loss: ${results.experience_gain_loss:,.0f}")
```

## Roll-Forward Formula

```
Expected_EOY = BOY_TOL + Service_Cost + Interest_Cost - Benefit_Payments
Experience = Actual_EOY - Expected_EOY (adjusted for assumption changes)
```

## License

MIT License
